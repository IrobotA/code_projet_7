sudo apt-get update && apt-get install -y --no-install-recommends apt-utils
sudo apt-get install libgomp1
gunicorn -w 4 -k uvicorn.workers.UvicornWorker app:app

